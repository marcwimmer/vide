# vim-openerp-browser
